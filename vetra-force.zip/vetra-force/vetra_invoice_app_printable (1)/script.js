
const offences = {
  1: { offence: "Violation of routes by commercial vehicles", points: 2, fine: "₦20,000.00 / ₦30,000.00", additional: "Impound vehicle + LASDRI" },
  2: { offence: "Non-display of route and number on vehicle", points: 2, fine: "₦20,000.00 / ₦30,000.00", additional: "Impound vehicle + LASDRI" },
  3: { offence: "Disobeying traffic control personnel", points: 2, fine: "₦20,000.00 / ₦30,000.00", additional: "Impound vehicle + LASDRI" },
  4: { offence: "Parking on yellow line / illegal parking", points: 4, fine: "₦20,000.00 / ₦30,000.00", additional: "Impound vehicle + LASDRI" },
  5: { offence: "Neglect of traffic directions", points: 2, fine: "Forfeiture of vehicle", additional: "6 months imprisonment / community service" },
  6: { offence: "Crossing double yellow line / centre line", points: 1, fine: "₦20,000.00 / ₦30,000.00", additional: "Impound vehicle + LASDRI training" },
  7: { offence: "Staying within the yellow junction box", points: 3, fine: "₦20,000.00 / ₦30,000.00", additional: "Impound vehicle + LASDRI training" },
  8: { offence: "Failure to yield at Zebra crossing", points: 1, fine: "₦20,000.00 / ₦30,000.00", additional: "Impound vehicle + LASDRI" },
  9: { offence: "Failure to give way to vehicle on left", points: 2, fine: "₦20,000.00 / ₦30,000.00", additional: "Impound vehicle + LASDRI" },
  10: { offence: "Smoking/drinking alcohol while driving", points: 1, fine: "₦20,000.00", additional: "3 months imprisonment / community service" },
  11: { offence: "Riding motorcycle without helmet", points: 1, fine: "₦20,000.00", additional: "3 months imprisonment / community service" },
  12: { offence: "Riding motorcycle without permit", points: 2, fine: "₦20,000.00", additional: "Impound motorcycle until permit" }
};

document.getElementById("invoiceForm").onsubmit = function (e) {
  e.preventDefault();
  const name = document.getElementById("offenderName").value;
  const phone = document.getElementById("offenderPhone").value;
  const plate = document.getElementById("plateNumber").value;
  const offenceId = document.getElementById("offenceSelect").value;
  const data = offences[offenceId];

  document.getElementById("invName").textContent = name;
  document.getElementById("invPhone").textContent = phone;
  document.getElementById("invPlate").textContent = plate;
  document.getElementById("invOffence").textContent = data.offence;
  document.getElementById("invPoints").textContent = data.points;
  document.getElementById("invFine").textContent = data.fine;
  document.getElementById("invAdditional").textContent = data.additional;

  document.getElementById("invoice").classList.remove("hidden");
};
